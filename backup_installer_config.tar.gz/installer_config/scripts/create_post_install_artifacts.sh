#!/bin/bash
set -x

sudo yum -y install expect

expect -c '
spawn qpc server login
expect "User name: "
send "admin\r"
expect "Password: "
send "pass\r"
interact'

expect -c '
spawn qpc cred add --name NRootCred --type network --username root --password
expect "Password: "
send "r3dh@t\r"
interact'

expect -c '
spawn qpc cred add --name NSudoCred --type network --username scanadminpwd --password --become-password
expect "Password: "
send "redhat\r"
expect "Provide a privilege escalation password to be used when running a network scan."
expect "Password: "
send "redhat\r"
interact'

qpc cred add --name NGoodKeyCred --type network --username root --sshkeyfile ~/.ssh/id_sonar_jenkins_rsa
qpc cred add --name NBadKeyCred --type network --username root --sshkeyfile ~/.ssh/id_sonar_jenkins_rsa.pub
qpc cred add --name NUntrustedCred --type network --username scanbasic --sshkeyfile ../qpc_helper/id_sonar_jenkins_rsa

expect -c '
spawn qpc cred add --name VCreds --type vcenter --username chambrid --password
expect "Password: "
send "Redhat2!\r"
interact'

expect -c '
spawn qpc cred add --name SCreds5 --type satellite --username admin --password
expect "Password: "
send "nimda\r"
interact'

expect -c '
spawn qpc cred add --name SCreds61 --type satellite --username admin --password
expect "Password: "
send "changeme\r"
interact'

expect -c '
spawn qpc cred add --name SCreds62 --type satellite --username admin --password
expect "Password: "
send "changeme\r"
interact'

echo "Creating range scan to determine current ip addresses"

qpc source add --name NLargeSource --type network --hosts ./systems.txt --cred NRootCred
qpc source add --name NLargeSudoSource --type network --hosts ./systems.txt --cred NSudoCred
qpc source add --name NLargeUntrustedSource --type network --hosts ./systems.txt --cred NUntrustedCred

qpc source add --name VSource --type vcenter --ssl-cert-verify=False --hosts "vcenter.toledo.satellite.lab.eng.rdu2.redhat.com" --port 443 --cred VCreds
qpc source add --name VSourceDup --type vcenter --ssl-cert-verify=False --hosts "vcenter.toledo.satellite.lab.eng.rdu2.redhat.com" --port 443 --cred VCreds

qpc source add --name S5Source --type satellite --ssl-cert-verify=False --hosts "pandora.usersys.redhat.com" --cred SCreds5

# lie that the 6.1 is 6.2 to get around validation
qpc source add --name S61Source --type satellite --ssl-cert-verify=False --hosts "sat-r220-01.lab.eng.rdu2.redhat.com" --cred SCreds61
qpc source add --name S62Source --type satellite --ssl-cert-verify=False --hosts "sat-r220-07.lab.eng.rdu2.redhat.com" --cred SCreds62
qpc source add --name S62SourceDup --type satellite --ssl-cert-verify=False --hosts "sat-r220-07.lab.eng.rdu2.redhat.com" --cred SCreds62

qpc scan add --name NLargeDefaultScan --sources NLargeSource
qpc scan add --name NLargeDefaultSudoScan --sources NLargeSudoSource
qpc scan add --name NLargeDefaultUntrustedScan --sources NLargeUntrustedSource

qpc scan add --name NLargeDisableJWSScan --sources NLargeSource --disabled-optional-products jboss_ws
qpc scan add --name NLargeDisableJWSSudoScan --sources NLargeSudoSource --disabled-optional-products jboss_ws
qpc scan add --name NLargeDisableJWSUntrusteScan --sources NLargeUntrustedSource --disabled-optional-products jboss_ws

qpc scan add --name NLargeExtendedSearchJWSScan --sources NLargeSource --enabled-ext-product-search jboss_ws
qpc scan add --name NLargeExtendedSearchJWSSudoScan --sources NLargeSudoSource --enabled-ext-product-search jboss_ws
qpc scan add --name NLargeExtendedSearchJWSUntrusteScan --sources NLargeUntrustedSource --enabled-ext-product-search jboss_ws

qpc scan add --name VScan --sources VSource
qpc scan add --name VScanDup --sources VSource VSourceDup

qpc scan add --name S5Scan --sources S5Source

qpc scan add --name S61Scan --sources S61Source
qpc scan add --name S62Scan --sources S62Source
qpc scan add --name S62ScanDup --sources S62Source S62SourceDup

qpc scan add --name NLargeScan --sources NLargeSource

qpc scan add --name LargeMixScan --sources NLargeSource S62Source VSource

